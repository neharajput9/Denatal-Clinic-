// =============================================
//  MANJULA DENTAL CLINIC — MAIN JAVASCRIPT
// =============================================

/* ---- Navbar Scroll Effect ---- */
const navbar = document.getElementById('navbar');
window.addEventListener('scroll', () => {
  if (window.scrollY > 30) {
    navbar.classList.add('scrolled');
  } else {
    navbar.classList.remove('scrolled');
  }
});

/* ---- Mobile Hamburger Menu ---- */
const hamburger = document.getElementById('hamburger');
const navLinks = document.getElementById('navLinks');
if (hamburger && navLinks) {
  hamburger.addEventListener('click', () => {
    navLinks.classList.toggle('open');
    const spans = hamburger.querySelectorAll('span');
    if (navLinks.classList.contains('open')) {
      spans[0].style.transform = 'rotate(45deg) translate(5px, 5px)';
      spans[1].style.opacity = '0';
      spans[2].style.transform = 'rotate(-45deg) translate(5px, -5px)';
    } else {
      spans[0].style.transform = '';
      spans[1].style.opacity = '';
      spans[2].style.transform = '';
    }
  });

  // Close menu when a link is clicked
  navLinks.querySelectorAll('.nav-link').forEach(link => {
    link.addEventListener('click', () => {
      navLinks.classList.remove('open');
      const spans = hamburger.querySelectorAll('span');
      spans[0].style.transform = '';
      spans[1].style.opacity = '';
      spans[2].style.transform = '';
    });
  });
}

/* ---- Scroll Animation Observer ---- */
const observerOptions = {
  threshold: 0.12,
  rootMargin: '0px 0px -40px 0px'
};
const observer = new IntersectionObserver((entries) => {
  entries.forEach(entry => {
    if (entry.isIntersecting) {
      entry.target.classList.add('is-visible');
      observer.unobserve(entry.target);
    }
  });
}, observerOptions);

// Observe cards and sections
document.querySelectorAll('.service-card, .service-full-card, .clinic-card, .why-card, .highlight-item').forEach(el => {
  el.style.opacity = '0';
  el.style.transform = 'translateY(24px)';
  el.style.transition = 'opacity 0.55s ease, transform 0.55s ease';
  observer.observe(el);
});

// When visible, animate in
const styleSheet = document.styleSheets[0];
if (styleSheet) {
  try {
    styleSheet.insertRule(`.is-visible { opacity: 1 !important; transform: translateY(0) !important; }`, styleSheet.cssRules.length);
  } catch(e) {}
}

/* ---- Staggered card animations ---- */
document.querySelectorAll('.services-grid, .services-full-grid, .why-grid').forEach(grid => {
  Array.from(grid.children).forEach((child, i) => {
    child.style.transitionDelay = `${i * 0.08}s`;
  });
});

// =============================================
//  GOOGLE SHEETS & WHATSAPP CONFIGURATION
// =============================================
const CLINIC_WHATSAPP_NUMBER = '919665047888';
const CALLMEBOT_API_KEY = '';
const GOOGLE_SCRIPT_STORAGE_KEY = 'manjula_google_script_url';
const APPOINTMENTS_STORAGE_KEY = 'manjula_clinic_appointments';
const CONTACTS_STORAGE_KEY = 'manjula_clinic_contacts';
const DEFAULT_GOOGLE_SCRIPT_URL = 'https://script.google.com/macros/s/AKfycbybogylT0aFu6nuEoi4Ne5_VYPoLs3ATYGQB2Ehv8mXdfNigaaeQNy0mu5uVmmRe730/exec';

function getGoogleScriptUrl() {
  return localStorage.getItem(GOOGLE_SCRIPT_STORAGE_KEY) || DEFAULT_GOOGLE_SCRIPT_URL;
}

function saveGoogleScriptUrl() {
  const input = document.getElementById('googleScriptUrlInput');
  if (input) {
    const url = input.value.trim();
    localStorage.setItem(GOOGLE_SCRIPT_STORAGE_KEY, url);
    alert('Google Apps Script URL saved successfully!');
    toggleSettingsModal();
  }
}

function getStoredAppointments() {
  const data = localStorage.getItem(APPOINTMENTS_STORAGE_KEY);
  if (!data) return [];
  try { return JSON.parse(data); } catch(e) { return []; }
}

function saveAppointment(appt) {
  const appts = getStoredAppointments();
  appts.unshift(appt);
  localStorage.setItem(APPOINTMENTS_STORAGE_KEY, JSON.stringify(appts));
}

function getStoredContacts() {
  const data = localStorage.getItem(CONTACTS_STORAGE_KEY);
  if (!data) return [];
  try { return JSON.parse(data); } catch(e) { return []; }
}

function saveContact(contact) {
  const contacts = getStoredContacts();
  contacts.unshift(contact);
  localStorage.setItem(CONTACTS_STORAGE_KEY, JSON.stringify(contacts));
}

function syncToGoogleSheets(payload) {
  const scriptUrl = getGoogleScriptUrl();
  if (scriptUrl) {
    fetch(scriptUrl, {
      method: 'POST',
      mode: 'no-cors',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    }).catch(err => console.error('Google Sheets sync error:', err));
  }
}

function seedSampleDataIfEmpty() {
  const existing = getStoredAppointments();
  if (existing.length === 0) {
    const today = new Date().toISOString().split('T')[0];
    const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
    const sampleData = [
      {
        id: 'APT-1001',
        firstName: 'Rahul',
        lastName: 'Sharma',
        phone: '+91 98234 56789',
        email: 'rahul.sharma@example.com',
        clinic: 'nashik',
        clinicName: 'Nashik Clinic',
        apptDate: today,
        apptTime: '10:00 AM',
        service: 'Teeth Cleaning & Scaling',
        notes: 'Regular checkup & cleaning',
        status: 'Confirmed',
        createdAt: new Date().toISOString()
      },
      {
        id: 'APT-1002',
        firstName: 'Priya',
        lastName: 'Patil',
        phone: '+91 97654 32109',
        email: 'priya.p@example.com',
        clinic: 'shindkheda',
        clinicName: 'Shindkheda Clinic',
        apptDate: today,
        apptTime: '11:30 AM',
        service: 'Root Canal Treatment',
        notes: 'Toothache on upper right molar',
        status: 'Pending',
        createdAt: new Date().toISOString()
      },
      {
        id: 'APT-1003',
        firstName: 'Amit',
        lastName: 'Deshmukh',
        phone: '+91 99123 45678',
        email: 'amit.d@example.com',
        clinic: 'nashik',
        clinicName: 'Nashik Clinic',
        apptDate: tomorrow,
        apptTime: '04:00 PM',
        service: 'Braces & Clear Aligners',
        notes: 'Consultation for teeth alignment',
        status: 'Pending',
        createdAt: new Date().toISOString()
      },
      {
        id: 'APT-1004',
        firstName: 'Sneha',
        lastName: 'Kulkarni',
        phone: '+91 98901 23456',
        email: 'sneha.k@example.com',
        clinic: 'shindkheda',
        clinicName: 'Shindkheda Clinic',
        apptDate: tomorrow,
        apptTime: '02:00 PM',
        service: 'Teeth Whitening',
        notes: 'Wedding upcoming next week',
        status: 'Completed',
        createdAt: new Date().toISOString()
      }
    ];
    localStorage.setItem(APPOINTMENTS_STORAGE_KEY, JSON.stringify(sampleData));
  }
}

function sendAutomaticWhatsAppNotification(text) {
  try {
    if (typeof CALLMEBOT_API_KEY !== 'undefined' && CALLMEBOT_API_KEY) {
      const apiUrl = `https://api.callmebot.com/whatsapp.php?phone=${CLINIC_WHATSAPP_NUMBER}&text=${encodeURIComponent(text)}&apikey=${CALLMEBOT_API_KEY}`;
      fetch(apiUrl, { mode: 'no-cors' }).catch(() => {});
    }
  } catch(e) {
    console.warn('Notification bypass:', e);
  }
}
const appointmentForm = document.getElementById('appointmentForm');
const formSuccess = document.getElementById('formSuccess');
const confirmedClinic = document.getElementById('confirmedClinic');
const formCard = document.getElementById('formCard');

if (appointmentForm) {
  // Pre-select clinic from URL params
  const urlParams = new URLSearchParams(window.location.search);
  const clinicParam = urlParams.get('clinic');
  if (clinicParam) {
    const clinicSelect = document.getElementById('clinic');
    if (clinicSelect) {
      const options = Array.from(clinicSelect.options);
      const match = options.find(o => o.value === clinicParam);
      if (match) clinicSelect.value = match.value;
    }
  }

  // Set minimum date to today
  const dateInput = document.getElementById('apptDate');
  if (dateInput) {
    const today = new Date().toISOString().split('T')[0];
    dateInput.min = today;
  }

  appointmentForm.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!appointmentForm.checkValidity()) {
      appointmentForm.querySelectorAll(':invalid').forEach(field => {
        field.style.borderColor = '#ef4444';
        field.addEventListener('input', () => { field.style.borderColor = ''; }, { once: true });
      });
      return;
    }

    const submitBtn = document.getElementById('submitBtn');
    if (submitBtn) {
      submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
      submitBtn.disabled = true;
    }

    const firstName = document.getElementById('firstName')?.value.trim() || '';
    const lastName = document.getElementById('lastName')?.value.trim() || '';
    const phone = document.getElementById('phone')?.value.trim() || '';
    const email = document.getElementById('email')?.value.trim() || 'N/A';
    const clinicVal = document.getElementById('clinic')?.value || '';
    const clinicName = clinicVal === 'nashik' ? 'Nashik Clinic' : (clinicVal === 'shindkheda' ? 'Shindkheda Clinic' : 'Not Selected');
    const apptDate = document.getElementById('apptDate')?.value || '';
    const apptTime = document.getElementById('apptTime')?.value || '';
    const service = document.getElementById('service')?.value || '';
    const notes = document.getElementById('message')?.value.trim() || 'None';

    const apptObj = {
      id: 'APT-' + Date.now().toString().slice(-5),
      firstName,
      lastName,
      phone,
      email,
      clinic: clinicVal,
      clinicName,
      apptDate,
      apptTime,
      service,
      notes,
      status: 'Pending',
      createdAt: new Date().toISOString()
    };

    try { saveAppointment(apptObj); } catch(err) { console.warn('Save appt error:', err); }
    try { syncToGoogleSheets(apptObj); } catch(err) { console.warn('Sheets sync error:', err); }

    const waText = 
`🦷 *NEW APPOINTMENT BOOKING* 🦷
----------------------------------
👤 *Patient Name:* ${firstName} ${lastName}
📞 *Phone Number:* ${phone}
📧 *Email:* ${email}

📍 *Clinic Location:* ${clinicName}
📅 *Preferred Date:* ${apptDate}
⏰ *Preferred Time:* ${apptTime}
🩺 *Treatment/Service:* ${service}

📝 *Additional Notes:*
${notes}
----------------------------------
_Sent via Manjul Dental Clinic Website_`;

    const waUrl = `https://wa.me/${CLINIC_WHATSAPP_NUMBER}?text=${encodeURIComponent(waText)}`;

    try { sendAutomaticWhatsAppNotification(waText); } catch(err) {}

    setTimeout(() => {
      const modalId = document.getElementById('apptModalId');
      const modalName = document.getElementById('apptModalName');
      const modalClinic = document.getElementById('apptModalClinic');
      const modalDateTime = document.getElementById('apptModalDateTime');
      const modalService = document.getElementById('apptModalService');
      const modalTitle = document.getElementById('apptModalTitle');

      if (modalId) modalId.textContent = apptObj.id;
      if (modalName) modalName.textContent = `${firstName} ${lastName}`.trim();
      if (modalClinic) modalClinic.textContent = clinicName;
      if (modalDateTime) modalDateTime.textContent = `${apptDate} at ${apptTime}`;
      if (modalService) modalService.textContent = service;
      if (modalTitle) modalTitle.innerHTML = `Thank You, ${firstName}! 😁`;

      // Show popup modal
      const apptModal = document.getElementById('appointmentSuccessModal');
      if (apptModal) {
        apptModal.style.display = 'flex';
      }

      // Reset submit button state
      if (submitBtn) {
        submitBtn.innerHTML = '<i class="fas fa-calendar-check"></i> Confirm Appointment';
        submitBtn.disabled = false;
      }
    }, 300);
  });
}

function closeAppointmentModal(e) {
  if (e && e.target && e.target.classList.contains('modal-card')) {
    return;
  }
  const modal = document.getElementById('appointmentSuccessModal');
  if (modal) {
    modal.style.display = 'none';
  }
  const apptForm = document.getElementById('appointmentForm');
  if (apptForm) {
    apptForm.reset();
  }
}

/* ---- Contact Form ---- */
const contactForm = document.getElementById('contactForm');
const contactSuccess = document.getElementById('contactSuccess');

if (contactForm) {
  contactForm.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!contactForm.checkValidity()) {
      contactForm.querySelectorAll(':invalid').forEach(field => {
        field.style.borderColor = '#ef4444';
        field.addEventListener('input', () => { field.style.borderColor = ''; }, { once: true });
      });
      return;
    }

    const cBtn = contactForm.querySelector('button[type="submit"]');
    if (cBtn) {
      cBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Submitting...';
      cBtn.disabled = true;
    }

    const cName = document.getElementById('cName')?.value.trim() || '';
    const cPhone = document.getElementById('cPhone')?.value.trim() || '';
    const cMsg = document.getElementById('cMsg')?.value.trim() || '';

    const contactObj = {
      id: 'CNT-' + Date.now().toString().slice(-5),
      name: cName,
      phone: cPhone,
      message: cMsg,
      createdAt: new Date().toISOString()
    };

    try { saveContact(contactObj); } catch(err) { console.warn('Save contact error:', err); }
    try { syncToGoogleSheets(contactObj); } catch(err) { console.warn('Sheets sync error:', err); }

    const waText = 
`💬 *NEW WEBSITE INQUIRY* 💬
----------------------------------
👤 *Name:* ${cName}
📞 *Phone Number:* ${cPhone}
📝 *Message:*
${cMsg}
----------------------------------
_Sent via Manjul Dental Clinic Website_`;

    const waUrl = `https://wa.me/${CLINIC_WHATSAPP_NUMBER}?text=${encodeURIComponent(waText)}`;

    try { sendAutomaticWhatsAppNotification(waText); } catch(err) {}

    setTimeout(() => {
      // Set dynamic details in the kind success modal
      const modalName = document.getElementById('contactModalName');
      const modalPhone = document.getElementById('contactModalPhone');
      const modalTitle = document.getElementById('contactModalTitle');
      const modalMsg = document.getElementById('contactModalMessage');
      const modalWaBtn = document.getElementById('modalContactWaBtn');

      const firstName = cName ? cName.split(' ')[0] : 'there';

      if (modalName) modalName.textContent = cName || 'Valued Patient';
      if (modalPhone) modalPhone.textContent = cPhone || '-';
      if (modalTitle) modalTitle.innerHTML = `Thank You, ${firstName}! 😁`;
      if (modalMsg) {
        modalMsg.innerHTML = `We are delighted to receive your message! Dr. Pranavkumar K. Gosavi & our care team at Manjul Dental Clinic truly appreciate you reaching out. Keep smiling, we will get back to you very soon! 😁✨`;
      }
      if (modalWaBtn) modalWaBtn.href = waUrl;

      // Show popup modal
      const modal = document.getElementById('contactSuccessModal');
      if (modal) {
        modal.style.display = 'flex';
      }

      // Reset submit button state
      if (cBtn) {
        cBtn.innerHTML = '<i class="fas fa-paper-plane"></i> Send Message';
        cBtn.disabled = false;
      }
    }, 300);
  });
}

function closeContactModal(e) {
  if (e && e.target && e.target.classList.contains('modal-card')) {
    return;
  }
  const modal = document.getElementById('contactSuccessModal');
  if (modal) {
    modal.style.display = 'none';
  }
  const contactForm = document.getElementById('contactForm');
  if (contactForm) {
    contactForm.reset();
  }
}

// Global ESC key listener to close open modals
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    closeAppointmentModal();
    closeContactModal();
  }
});

/* ---- Map Tab Switcher ---- */
function switchMap(location) {
  const nashikMap = document.getElementById('mapNashik');
  const shindkhedaMap = document.getElementById('mapShindkheda');
  const tabNashik = document.getElementById('tabNashik');
  const tabShindkheda = document.getElementById('tabShindkheda');

  if (location === 'nashik') {
    if (nashikMap) { nashikMap.classList.add('active'); }
    if (shindkhedaMap) { shindkhedaMap.classList.remove('active'); }
    if (tabNashik) { tabNashik.classList.add('active'); }
    if (tabShindkheda) { tabShindkheda.classList.remove('active'); }
  } else {
    if (shindkhedaMap) { shindkhedaMap.classList.add('active'); }
    if (nashikMap) { nashikMap.classList.remove('active'); }
    if (tabShindkheda) { tabShindkheda.classList.add('active'); }
    if (tabNashik) { tabNashik.classList.remove('active'); }
  }
}

/* ---- Smooth scroll for anchor links ---- */
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', (e) => {
    const target = document.querySelector(anchor.getAttribute('href'));
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});

/* ---- Dynamic open/closed status ---- */
function updateClinicStatus() {
  const now = new Date();
  const day = now.getDay(); // 0=Sun, 1=Mon...5=Fri, 6=Sat
  const hour = now.getHours();
  const minute = now.getMinutes();
  const time = hour * 60 + minute;

  // Nashik: Mon-Fri (1-5), 9am-8pm (540-1200)
  const nashikOpen = day >= 1 && day <= 5 && time >= 540 && time < 1200;

  // Shindkheda: Sun (0) & Mon (1), 8am-8pm (480-1200)
  const shindkhedaOpen = (day === 0 || day === 1) && time >= 480 && time < 1200;

  const statusEls = document.querySelectorAll('.clinic-status');
  if (statusEls.length >= 2) {
    updateStatus(statusEls[0], nashikOpen);
    updateStatus(statusEls[1], shindkhedaOpen);
  }
}

function updateStatus(el, isOpen) {
  if (!el) return;
  el.className = `clinic-status ${isOpen ? 'open' : 'closed'}`;
  el.innerHTML = `<i class="fas fa-circle"></i> ${isOpen ? 'Open Now' : 'Closed'}`;
  if (!isOpen) {
    el.style.color = '#ef4444';
  }
}

updateClinicStatus();

/* ---- Counting animation for hero stats ---- */
function animateCount(el, target, duration = 1800) {
  let start = 0;
  const step = target / (duration / 16);
  const timer = setInterval(() => {
    start += step;
    if (start >= target) {
      el.textContent = target.toLocaleString() + (el.dataset.suffix || '');
      clearInterval(timer);
    } else {
      el.textContent = Math.floor(start).toLocaleString() + (el.dataset.suffix || '');
    }
  }, 16);
}

const statNums = document.querySelectorAll('.stat-num');
const statsSection = document.querySelector('.hero-stats');
if (statsSection && statNums.length) {
  const statsObserver = new IntersectionObserver((entries) => {
    if (entries[0].isIntersecting) {
      const targets = [5000, 15, 2];
      const suffixes = ['+', '+', ''];
      statNums.forEach((el, i) => {
        el.dataset.suffix = suffixes[i];
        animateCount(el, targets[i]);
      });
      statsObserver.unobserve(statsSection);
    }
  }, { threshold: 0.5 });
  statsObserver.observe(statsSection);
}

// =============================================
//  ADMIN AUTHENTICATION & SECURITY CONTROL
// =============================================
const ADMIN_AUTH_KEY = 'manjula_admin_logged_in';
const ADMIN_CREDS_KEY = 'manjula_admin_credentials';
const ADMIN_LOCK_KEY = 'manjula_admin_lockout';
let loginFailedAttempts = 0;

function getAdminCredentials() {
  const creds = localStorage.getItem(ADMIN_CREDS_KEY);
  if (!creds) {
    const defaultCreds = { username: 'admin', password: 'admin123' };
    localStorage.setItem(ADMIN_CREDS_KEY, JSON.stringify(defaultCreds));
    return defaultCreds;
  }
  try { return JSON.parse(creds); } catch(e) {
    return { username: 'admin', password: 'admin123' };
  }
}

function checkAdminLoggedIn() {
  const sessionAuth = sessionStorage.getItem(ADMIN_AUTH_KEY);
  const localAuth = localStorage.getItem(ADMIN_AUTH_KEY);
  return sessionAuth === 'true' || localAuth === 'true';
}

function initAdminAuth() {
  const loginSection = document.getElementById('adminLoginSection');
  const dashboardSection = document.getElementById('adminDashboardSection');

  if (!loginSection || !dashboardSection) return;

  if (checkAdminLoggedIn()) {
    loginSection.style.display = 'none';
    dashboardSection.style.display = 'block';
    initAdminDashboard();
  } else {
    loginSection.style.display = 'flex';
    dashboardSection.style.display = 'none';
  }
}

function handleAdminLogin(e) {
  if (e) e.preventDefault();

  const usernameInput = document.getElementById('adminUsername');
  const passwordInput = document.getElementById('adminPassword');
  const rememberMe = document.getElementById('adminRememberMe');
  const errorAlert = document.getElementById('loginErrorAlert');

  if (!usernameInput || !passwordInput) return;

  const inputUsername = usernameInput.value.trim().toLowerCase();
  const inputPassword = passwordInput.value.trim();

  // Check Lockout
  const lockUntil = parseInt(localStorage.getItem(ADMIN_LOCK_KEY) || '0', 10);
  const now = Date.now();
  if (lockUntil > now) {
    const secondsLeft = Math.ceil((lockUntil - now) / 1000);
    showLoginError(`Security Lockout Active! Too many failed attempts. Try again in ${secondsLeft} second(s).`);
    return;
  }

  const creds = getAdminCredentials();
  const storedUsername = (creds.username || 'admin').toLowerCase();
  const storedPassword = creds.password || 'admin123';

  // Flexible login check: matches saved username/email, default 'admin', or user's email if password matches
  const isDefaultPassword = (storedPassword === 'admin123' && inputPassword === 'admin123');
  const isUsernameMatch = (inputUsername === storedUsername || inputUsername === 'admin' || inputUsername === 'giraserahul84@gmail.com');
  const isPasswordMatch = (inputPassword === storedPassword);

  if ((isUsernameMatch && isPasswordMatch) || (isDefaultPassword && inputUsername.length > 0)) {
    // Login Successful
    loginFailedAttempts = 0;
    localStorage.removeItem(ADMIN_LOCK_KEY);

    // Save input username/email if customized
    if (inputUsername && inputUsername !== storedUsername) {
      creds.username = inputUsername;
      localStorage.setItem(ADMIN_CREDS_KEY, JSON.stringify(creds));
    }

    if (rememberMe && rememberMe.checked) {
      localStorage.setItem(ADMIN_AUTH_KEY, 'true');
    } else {
      sessionStorage.setItem(ADMIN_AUTH_KEY, 'true');
    }

    if (errorAlert) errorAlert.style.display = 'none';
    usernameInput.value = '';
    passwordInput.value = '';

    initAdminAuth();
  } else {
    // Login Failed
    loginFailedAttempts++;
    if (loginFailedAttempts >= 5) {
      const lockTime = Date.now() + 30000; // 30 seconds lockout
      localStorage.setItem(ADMIN_LOCK_KEY, lockTime.toString());
      loginFailedAttempts = 0;
      showLoginError('Security Alert: 5 consecutive failed login attempts. Locked for 30 seconds.');
    } else {
      showLoginError(`Invalid Username/Email or Password. (${5 - loginFailedAttempts} attempt(s) remaining)`);
    }
  }
}

function showLoginError(msg) {
  const errorAlert = document.getElementById('loginErrorAlert');
  if (errorAlert) {
    errorAlert.innerHTML = `<i class="fas fa-circle-exclamation"></i> ${escapeHtml(msg)}`;
    errorAlert.style.display = 'flex';
  }
}

function handleAdminLogout() {
  if (confirm('Are you sure you want to log out of the Admin Dashboard?')) {
    sessionStorage.removeItem(ADMIN_AUTH_KEY);
    localStorage.removeItem(ADMIN_AUTH_KEY);
    initAdminAuth();
  }
}

function togglePasswordVisibility(inputId, iconId) {
  const input = document.getElementById(inputId);
  const icon = document.getElementById(iconId);
  if (input && icon) {
    if (input.type === 'password') {
      input.type = 'text';
      icon.classList.remove('fa-eye');
      icon.classList.add('fa-eye-slash');
    } else {
      input.type = 'password';
      icon.classList.remove('fa-eye-slash');
      icon.classList.add('fa-eye');
    }
  }
}

function toggleChangePasswordModal() {
  const modal = document.getElementById('changePasswordModal');
  if (modal) {
    const isHidden = modal.style.display === 'none' || !modal.style.display;
    modal.style.display = isHidden ? 'flex' : 'none';
    if (isHidden) {
      const currPass = document.getElementById('currentPasswordInput');
      const newPass = document.getElementById('newPasswordInput');
      const confirmPass = document.getElementById('confirmPasswordInput');
      const alertBox = document.getElementById('changePassAlert');
      if (currPass) currPass.value = '';
      if (newPass) newPass.value = '';
      if (confirmPass) confirmPass.value = '';
      if (alertBox) alertBox.style.display = 'none';
    }
  }
}

function handleChangePassword(e) {
  if (e) e.preventDefault();
  const currPass = document.getElementById('currentPasswordInput')?.value.trim();
  const newPass = document.getElementById('newPasswordInput')?.value.trim();
  const confirmPass = document.getElementById('confirmPasswordInput')?.value.trim();
  const alertBox = document.getElementById('changePassAlert');

  const creds = getAdminCredentials();

  if (currPass !== creds.password) {
    if (alertBox) {
      alertBox.className = 'alert-danger';
      alertBox.innerHTML = '<i class="fas fa-circle-exclamation"></i> Current password is incorrect!';
      alertBox.style.display = 'block';
    }
    return;
  }

  if (!newPass || newPass.length < 6) {
    if (alertBox) {
      alertBox.className = 'alert-danger';
      alertBox.innerHTML = '<i class="fas fa-circle-exclamation"></i> New password must be at least 6 characters!';
      alertBox.style.display = 'block';
    }
    return;
  }

  if (newPass !== confirmPass) {
    if (alertBox) {
      alertBox.className = 'alert-danger';
      alertBox.innerHTML = '<i class="fas fa-circle-exclamation"></i> New passwords do not match!';
      alertBox.style.display = 'block';
    }
    return;
  }

  // Update saved password
  creds.password = newPass;
  localStorage.setItem(ADMIN_CREDS_KEY, JSON.stringify(creds));

  if (alertBox) {
    alertBox.className = 'alert-success';
    alertBox.innerHTML = '<i class="fas fa-circle-check"></i> Admin password changed successfully!';
    alertBox.style.display = 'block';
  }

  setTimeout(() => {
    toggleChangePasswordModal();
  }, 1200);
}

// =============================================
//  ADMIN DASHBOARD STATE & RENDER LOGIC
// =============================================
let currentClinicFilter = 'all'; // 'all', 'nashik', 'shindkheda', 'contacts'

function initAdminDashboard() {
  if (!checkAdminLoggedIn()) return;
  seedSampleDataIfEmpty();

  // Set default date input to today
  const dateInput = document.getElementById('adminDateFilter');
  if (dateInput) {
    const today = new Date().toISOString().split('T')[0];
    dateInput.value = today;
  }

  // Pre-fill saved Google Script URL
  const scriptInput = document.getElementById('googleScriptUrlInput');
  if (scriptInput) {
    scriptInput.value = getGoogleScriptUrl();
  }

  renderAdminDashboard();
}

function setClinicFilter(filter) {
  currentClinicFilter = filter;
  ['tabAll', 'tabNashikClinic', 'tabShindkhedaClinic', 'tabContacts'].forEach(id => {
    const tab = document.getElementById(id);
    if (tab) tab.classList.remove('active');
  });

  if (filter === 'all') document.getElementById('tabAll')?.classList.add('active');
  if (filter === 'nashik') document.getElementById('tabNashikClinic')?.classList.add('active');
  if (filter === 'shindkheda') document.getElementById('tabShindkhedaClinic')?.classList.add('active');
  if (filter === 'contacts') document.getElementById('tabContacts')?.classList.add('active');

  renderAdminDashboard();
}

function setFilterToday() {
  const dateInput = document.getElementById('adminDateFilter');
  if (dateInput) {
    dateInput.value = new Date().toISOString().split('T')[0];
    renderAdminDashboard();
  }
}

function setFilterTomorrow() {
  const dateInput = document.getElementById('adminDateFilter');
  if (dateInput) {
    const tomorrow = new Date(Date.now() + 86400000).toISOString().split('T')[0];
    dateInput.value = tomorrow;
    renderAdminDashboard();
  }
}

function clearDateFilter() {
  const dateInput = document.getElementById('adminDateFilter');
  if (dateInput) {
    dateInput.value = '';
    renderAdminDashboard();
  }
}

function renderAdminDashboard() {
  if (!checkAdminLoggedIn()) return;
  const tbody = document.getElementById('appointmentsTbody');
  if (!tbody) return;

  const dateVal = document.getElementById('adminDateFilter')?.value || '';
  const statusVal = document.getElementById('adminStatusFilter')?.value || 'all';
  const searchVal = (document.getElementById('adminSearchInput')?.value || '').toLowerCase();

  const allAppts = getStoredAppointments();
  const allContacts = getStoredContacts();

  // Update KPI counters
  const todayStr = new Date().toISOString().split('T')[0];
  document.getElementById('kpiTotal').textContent = allAppts.length;
  document.getElementById('kpiToday').textContent = allAppts.filter(a => a.apptDate === todayStr).length;
  document.getElementById('kpiNashik').textContent = allAppts.filter(a => a.clinic === 'nashik').length;
  document.getElementById('kpiShindkheda').textContent = allAppts.filter(a => a.clinic === 'shindkheda').length;

  if (currentClinicFilter === 'contacts') {
    renderContactsTable(allContacts, searchVal);
    return;
  }

  // Filter Appointments
  let filtered = allAppts.filter(item => {
    // Clinic filter
    if (currentClinicFilter === 'nashik' && item.clinic !== 'nashik') return false;
    if (currentClinicFilter === 'shindkheda' && item.clinic !== 'shindkheda') return false;

    // Daywise date filter
    if (dateVal && item.apptDate !== dateVal) return false;

    // Status filter
    if (statusVal !== 'all' && item.status !== statusVal) return false;

    // Search filter
    if (searchVal) {
      const fullName = (item.firstName + ' ' + item.lastName).toLowerCase();
      const phone = (item.phone || '').toLowerCase();
      const service = (item.service || '').toLowerCase();
      if (!fullName.includes(searchVal) && !phone.includes(searchVal) && !service.includes(searchVal)) {
        return false;
      }
    }
    return true;
  });

  // Update Table Title & Count
  const resultsCount = document.getElementById('resultsCount');
  if (resultsCount) resultsCount.textContent = `Showing ${filtered.length} of ${allAppts.length} appointments`;

  const emptyState = document.getElementById('emptyState');
  if (filtered.length === 0) {
    tbody.innerHTML = '';
    if (emptyState) emptyState.style.display = 'block';
    return;
  }
  if (emptyState) emptyState.style.display = 'none';

  // Build Table Rows
  tbody.innerHTML = filtered.map((item, idx) => {
    const clinicBadge = item.clinic === 'nashik' 
      ? `<span class="badge badge-nashik"><i class="fas fa-hospital"></i> Nashik</span>`
      : `<span class="badge badge-shindkheda"><i class="fas fa-clinic-medical"></i> Shindkheda</span>`;

    const statusBadge = getStatusBadge(item.status);

    return `
      <tr>
        <td><strong>#${idx + 1}</strong></td>
        <td>
          <div style="font-weight: 700; color: var(--text-dark);">${escapeHtml(item.firstName)} ${escapeHtml(item.lastName)}</div>
          <small style="color: var(--text-light);">${escapeHtml(item.email)}</small>
        </td>
        <td><a href="tel:${escapeHtml(item.phone)}" style="color: var(--primary); font-weight: 600;"><i class="fas fa-phone"></i> ${escapeHtml(item.phone)}</a></td>
        <td>${clinicBadge}</td>
        <td><strong>${escapeHtml(item.apptDate)}</strong></td>
        <td><span class="time-pill"><i class="fas fa-clock"></i> ${escapeHtml(item.apptTime)}</span></td>
        <td><strong>${escapeHtml(item.service)}</strong></td>
        <td style="max-width: 180px; font-size: 0.82rem; color: var(--text-mid);">${escapeHtml(item.notes)}</td>
        <td>${statusBadge}</td>
        <td>
          <div class="action-btn-group">
            <select class="status-select" onchange="updateAppointmentStatus('${item.id}', this.value)">
              <option value="Pending" ${item.status === 'Pending' ? 'selected' : ''}>Pending</option>
              <option value="Confirmed" ${item.status === 'Confirmed' ? 'selected' : ''}>Confirmed</option>
              <option value="Completed" ${item.status === 'Completed' ? 'selected' : ''}>Completed</option>
              <option value="Cancelled" ${item.status === 'Cancelled' ? 'selected' : ''}>Cancelled</option>
            </select>
            <button class="btn-icon delete" title="Delete" onclick="deleteAppointment('${item.id}')">
              <i class="fas fa-trash-can"></i>
            </button>
          </div>
        </td>
      </tr>
    `;
  }).join('');
}

function renderContactsTable(contacts, searchVal) {
  const tbody = document.getElementById('appointmentsTbody');
  if (!tbody) return;

  const thead = document.querySelector('#adminAppointmentsTable thead');
  if (thead) {
    thead.innerHTML = `
      <tr>
        <th>#</th>
        <th>Name</th>
        <th>Phone Number</th>
        <th>Message</th>
        <th>Date Submitted</th>
        <th>Actions</th>
      </tr>
    `;
  }

  let filtered = contacts.filter(item => {
    if (searchVal) {
      const name = (item.name || '').toLowerCase();
      const phone = (item.phone || '').toLowerCase();
      const msg = (item.message || '').toLowerCase();
      if (!name.includes(searchVal) && !phone.includes(searchVal) && !msg.includes(searchVal)) return false;
    }
    return true;
  });

  const resultsCount = document.getElementById('resultsCount');
  if (resultsCount) resultsCount.textContent = `Showing ${filtered.length} general inquiries`;

  const emptyState = document.getElementById('emptyState');
  if (filtered.length === 0) {
    tbody.innerHTML = '';
    if (emptyState) emptyState.style.display = 'block';
    return;
  }
  if (emptyState) emptyState.style.display = 'none';

  tbody.innerHTML = filtered.map((item, idx) => `
    <tr>
      <td><strong>#${idx + 1}</strong></td>
      <td><strong>${escapeHtml(item.name)}</strong></td>
      <td><a href="tel:${escapeHtml(item.phone)}" style="color: var(--primary); font-weight:600;"><i class="fas fa-phone"></i> ${escapeHtml(item.phone)}</a></td>
      <td style="max-width: 300px; font-size:0.85rem;">${escapeHtml(item.message)}</td>
      <td>${new Date(item.createdAt).toLocaleDateString()}</td>
      <td>
        <button class="btn-icon delete" title="Delete" onclick="deleteContact('${item.id}')">
          <i class="fas fa-trash-can"></i>
        </button>
      </td>
    </tr>
  `).join('');
}

function getStatusBadge(status) {
  switch (status) {
    case 'Confirmed': return `<span class="badge badge-status-confirmed"><i class="fas fa-circle-check"></i> Confirmed</span>`;
    case 'Completed': return `<span class="badge badge-status-completed"><i class="fas fa-check-double"></i> Completed</span>`;
    case 'Cancelled': return `<span class="badge badge-status-cancelled"><i class="fas fa-circle-xmark"></i> Cancelled</span>`;
    default: return `<span class="badge badge-status-pending"><i class="fas fa-hourglass-half"></i> Pending</span>`;
  }
}

function updateAppointmentStatus(id, newStatus) {
  const appts = getStoredAppointments();
  const index = appts.findIndex(a => a.id === id);
  if (index !== -1) {
    appts[index].status = newStatus;
    localStorage.setItem(APPOINTMENTS_STORAGE_KEY, JSON.stringify(appts));
    renderAdminDashboard();
  }
}

function deleteAppointment(id) {
  if (confirm('Are you sure you want to delete this appointment booking?')) {
    const appts = getStoredAppointments().filter(a => a.id !== id);
    localStorage.setItem(APPOINTMENTS_STORAGE_KEY, JSON.stringify(appts));
    renderAdminDashboard();
  }
}

function deleteContact(id) {
  if (confirm('Are you sure you want to delete this contact message?')) {
    const contacts = getStoredContacts().filter(c => c.id !== id);
    localStorage.setItem(CONTACTS_STORAGE_KEY, JSON.stringify(contacts));
    renderAdminDashboard();
  }
}

function resetToSampleData() {
  if (confirm('Reset dashboard with fresh sample bookings for Nashik & Shindkheda?')) {
    localStorage.removeItem(APPOINTMENTS_STORAGE_KEY);
    seedSampleDataIfEmpty();
    renderAdminDashboard();
  }
}

function exportAppointmentsToCSV() {
  const appts = getStoredAppointments();
  if (appts.length === 0) {
    alert('No appointment records found to export!');
    return;
  }

  let csvContent = "data:text/csv;charset=utf-8,";
  csvContent += "ID,Patient Name,Phone Number,Email,Clinic Location,Appointment Date,Appointment Time,Service/Treatment,Notes,Status,Submitted At\n";

  appts.forEach(a => {
    const row = [
      `"${a.id}"`,
      `"${a.firstName} ${a.lastName}"`,
      `"${a.phone}"`,
      `"${a.email}"`,
      `"${a.clinicName}"`,
      `"${a.apptDate}"`,
      `"${a.apptTime}"`,
      `"${a.service}"`,
      `"${(a.notes || '').replace(/"/g, '""')}"`,
      `"${a.status}"`,
      `"${a.createdAt}"`
    ].join(",");
    csvContent += row + "\n";
  });

  const encodedUri = encodeURI(csvContent);
  const link = document.createElement("a");
  link.setAttribute("href", encodedUri);
  link.setAttribute("download", `Manjula_Dental_Appointments_${new Date().toISOString().split('T')[0]}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}

function toggleSettingsModal() {
  const modal = document.getElementById('settingsModal');
  if (modal) {
    modal.style.display = modal.style.display === 'none' || !modal.style.display ? 'flex' : 'none';
  }
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

